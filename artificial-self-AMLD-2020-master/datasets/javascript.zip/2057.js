var mediaPlugin = require('../media');

module.exports = {

    prepareLink: function(link, options) {

        mediaPlugin.prepareLink(link, options);
    }
};