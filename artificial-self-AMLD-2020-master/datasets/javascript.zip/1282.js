// Run "localonly" example but with profiling enabled
require('v8-profiler');
require('./localonly');
