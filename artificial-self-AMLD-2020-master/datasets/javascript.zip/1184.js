exports.Registry = require('./lib/registry').Registry;
exports.RedisDb = require('./lib/db/redis').RedisDb;