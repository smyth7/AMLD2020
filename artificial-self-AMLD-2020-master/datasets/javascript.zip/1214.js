module.exports = {
  app: {
    src: 'tmp/result/assets/**/*.css'
  }
};