module.exports = {
  'debug': ['tmp'],
  'dist': ['tmp', 'dist'],
  'tmp' : ['.tmp']
};
