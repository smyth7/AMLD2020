module.declare(
	function(require, exports, module) {
		exports.foo = function() { };
	}
);
