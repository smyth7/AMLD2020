module.exports = {

    getMeta: function(meta) {
        return {
            title: meta['html-title']
        };
    },

    lowestPriority: true
};
