require('blanket')({
  // Only files that match the pattern will be instrumented
  pattern: 'dynamoose/lib/'
});