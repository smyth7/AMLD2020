OfflineReader.RssView = Ember.View.extend({
  templateName: 'rss'
});
