/* Mongolian DeadBeef by Marcello Bastea-Forte - zlib license */

module.exports = require('./lib/bson')