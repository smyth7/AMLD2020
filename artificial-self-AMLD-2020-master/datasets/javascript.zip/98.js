'use strict';

angular.module('todoWebApp', ['ngAnimate']);