// define module for app
angular.module('SampleWizardApp', ['rcWizard', 'rcForm', 'rcDisabledBootstrap']);