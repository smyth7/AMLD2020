angular.module('ngHandsontable',
	[
		'ngHandsontable.services',
		'ngHandsontable.directives'
	]);
