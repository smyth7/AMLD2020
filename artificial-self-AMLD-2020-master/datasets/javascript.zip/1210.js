module.exports = {
  // Remaining configuration done in Gruntfile.js
  options: {
    logConcurrentOutput: true
  }
};
