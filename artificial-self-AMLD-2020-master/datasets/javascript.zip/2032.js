module.exports = {

    getMeta: function(meta) {
        return {
            copyright: meta.copyright
        };
    }
};