OfflineReader.RssesView = Ember.View.extend({
  templateName: 'rsses'
});
