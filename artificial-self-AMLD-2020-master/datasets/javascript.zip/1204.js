/*
Ockley 1.0
Copyright 2011,  Matthew Page
licensed under the MIT license: http://www.opensource.org/licenses/mit-license.php
*/
module.exports = {
  stylesheets: function() {
    return ["css/login.css", "libs/formly/formly.min.css"];
  },
  scripts: function(){
    return ["libs/formly/formly.min.js"];
  }
};

